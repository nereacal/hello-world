package ejercicio2;

import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
		
		String pass;  // Variable para almacenar la contraseña
		String intento;  // Variable para almacenar los intentos
		int maximo=3;   // Máximo de intentos
		Scanner leer = new Scanner(System.in);
		
		
		// Pide al usuario que ponga una contraseña y la guarda en variable
		System.out.println("Escribe una contraseña: ");
		pass = leer.next();
		
		
		/*
		 * Bucle de 3 ciclos, 1 por cada intento. El primer ciclo es 0 y el último es el número maximo (3)
		 * 
		 */
		for(int i=0; i<=maximo; i++) {
					
			
			// Lee el intento del usuario y lo almacena en variable "intento". El "maximo-i" son los intentos que le quedan. 
			System.out.println("Quedan "+(maximo-i)+" intentos. Escribe la contraseña: ");
			intento = leer.next();
			
			
			/*
			 * Evalúa si la contraseña y el intento coincide
			 *  Si no coincide y es el ultimo intento se cierra
			 */
			if(intento.equals(pass)) {
				System.out.println("De puta madre!");
				break;
			}else{
				
				if(i==maximo) {  // Si es igual a 0, es el último intento
					System.out.println("3 intentos fallidos, adiós!");
					System.exit(1);	 // Cierra el programa
				}
				else {   //Si no es el último intento
					System.out.println("No coincide, prueba otra vez");
				}
				
			}
			
			
		}
		

	}

}
