package ejercicio3;

public class Cuenta {
	
	/*
	 * Atributos de la clase 
	 * */
	private String titular;
	private String numeroCuenta;
	private double cantidad;
	
	// Constructor de clase
	public Cuenta(String titular, String numeroCuenta, double cantidad) {
		this.titular = titular;
		this.numeroCuenta = numeroCuenta;
		this.cantidad = cantidad;
	}
	
	
	// Métodos getter and setter
	public String getTitular() {
		return titular;
	}
	public void setTitular(String titular) {
		this.titular = titular;
	}
	public String getNumeroCuenta() {
		return numeroCuenta;
	}
	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}
	public double getCantidad() {
		return cantidad;
	}
	public void setCantidad(double cantidad) {
		this.cantidad = cantidad;
	}
	
	// Método que devuelve información de la cuenta
	public String toString() {
        return "El titular " + titular + " del número de cuenta " + numeroCuenta + " tiene " + cantidad + " euros en la cuenta";
    }
	

}
