package ejercicio3;

public class principal {

	public static void main(String[] args) {
		
		/*
		 * Se crean las 2 cuentas con valores por defecto (se pueden cambiar)
		 * Los valores por defecto (titular, num cuenta y cantidad) en la instancia de clase (new)
		 * */
		Cuenta cuenta1 = new Cuenta("Jehová", "0123456", 100.0);
		Cuenta cuenta2 = new Cuenta("Jesucristo", "6543210", 99.9);
		
		/*
		 *  Obtiene la cantidad que hay en cada cuenta con getCantidad y las guarda en variables
		 *  Luego evalua cuál tiene más cantidad y la muestra
		*/
		double cantidadCuenta1 = cuenta1.getCantidad();
		double cantidadCuenta2 = cuenta2.getCantidad();
		
		if(cantidadCuenta1 > cantidadCuenta2) {   // Si la cuenta 1 tiene más cantidad
			System.out.println("La cuenta de: " + cuenta1.getTitular() + " tiene más pasta. Tiene: " + cantidadCuenta1 + " euros");
		}
		else if(cantidadCuenta1 < cantidadCuenta2) {   // Si la cuenta 2 tiene más cantidad
			System.out.println("La cuenta de: " + cuenta2.getTitular() + " tiene más pasta. Tiene: " + cantidadCuenta2 + " euros");
		}
		else if(cantidadCuenta1 == cantidadCuenta2) {   // Si las cuentas tienen la misma cantidad
			System.out.println("La cuentas tiene la misma cantidad de euros: "+ cantidadCuenta1);
		}
		else {   // Si no cumple ninguna de las otras condiciones
			System.out.println("No se ha podido calcular la cantidad");
		}
		

	}

}
