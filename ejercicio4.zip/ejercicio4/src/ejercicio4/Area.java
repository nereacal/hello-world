package ejercicio4;

import java.util.Scanner;

public class Area {

	public static void main(String[] args) {
		
		// Variables
		double lado;
		double area;
		
		Scanner leer = new Scanner(System.in);
		System.out.println("Introduce el lado del cuadrado: ");
		lado = leer.nextDouble();
		
		// Función para calcular al cuadrado (Math.pow)
		area = Math.pow(lado, 2);
		System.out.println("El area es: " + area);

	}

}
