package ejercicio5;

import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		
		int numero;
		int factorial = 1;
		
		Scanner leer = new Scanner(System.in);
		System.out.println("Introduce un número: ");
		numero = leer.nextInt();
		
		// Bucle para ir calculando cada número entre el número dado y el 1
		for(int i = numero; i > 0; i--) {
			factorial = factorial * i;    // Calcula el factorial del número i en el ciclo del bucle y lo guarda en la variable factorial
		}
		System.out.println("El factorial de " + numero + " es: " + factorial);

	}

}
