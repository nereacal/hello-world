package ejercicio8;

import java.util.Scanner;

public class Primo {

	public static void main(String[] args) {
		
		int numero;
		
		Scanner leer = new Scanner(System.in);
		System.out.println("Introduce un número entre 0 y 100: ");
		numero = leer.nextInt();
		
		if((numero>0) && (numero < 100)) {  // Evalua si el número es mayor que 0 y menor que 100 para evaluar si es primo.
			
			if(esPrimo(numero)) {   // Invoca a la función booleana esPrimo pasando el número por parametro. Si esta condición devuelve true, es primo
				
				System.out.println("El número es primo");
				
			}
			else {
				
				System.out.println("El número no es primo");
			}
		}
		else {
			System.out.println("El número introducido no está entre el 0 y el 100");
		}

	}
	
	/*
	 * Función que devuelve un booleano (si es primo true y si no lo es false) y recibe por parámetro el número introducido.
	 * */
	public static Boolean esPrimo(int numero) {
				
		if(numero % 2 == 0) {   // Si el resto entre el número partido 2 es cero, no es primo
			
			return false;
			
		}
		
		for(int i = 3; i*i < numero; i+=2) {  // Buble que empieza en 3 y cada ciclo calcula el los primos hasta llegar al númeor intorducido por el usuario
			
			if(numero % i == 0) {   // Si el resto entre la división del numero introducido y entre el numero del ciclo es 0, devuelve falso (no es primo)
				
				return false;
				
			}
			
		}
		
		return true;   // Si no ha cumplido las condiciones anteriores, devuelve true, es primo.
	}

}
